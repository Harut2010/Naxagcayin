import sqlite3
import hashlib

DB = 'attendance.db'
conn = sqlite3.connect(DB)
c = conn.cursor()

c.execute("""
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('student','teacher','admin')) DEFAULT 'student'
);
""")

c.execute("""
CREATE TABLE IF NOT EXISTS attendance (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    date TEXT NOT NULL,
    status TEXT NOT NULL CHECK(status IN ('Present','Absent')),
    timestamp TEXT,
    FOREIGN KEY(user_id) REFERENCES users(id)
);
""")

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def add_user(u, p, r):
    cur = conn.execute("SELECT id FROM users WHERE username = ?", (u,))
    if cur.fetchone():
        return
    conn.execute("INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)",
                 (u, hash_password(p), r))

add_user('teacher', 'admin', 'teacher')
add_user('student1', '1234', 'student')
add_user('student2', 'abcd', 'student')

conn.commit()
conn.close()
print("Initialized database and created sample users.")
