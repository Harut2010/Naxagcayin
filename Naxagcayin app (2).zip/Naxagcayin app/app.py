from app import Flask, render_template, request, redirect, url_for, flash, session, send_file
import sqlite3
import hashlib
from datetime import date, datetime
import io
import csv

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def check_password(hashed, password):
    return hashed == hashlib.sha256(password.encode()).hexdigest()

DB = 'attendance.db'
app = Flask(__name__)
app.secret_key = 'replace-this-with-a-random-secret'

def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def query_db(query, args=(), one=False):
    conn = get_db()
    cur = conn.execute(query, args)
    rv = cur.fetchall()
    conn.commit()
    conn.close()
    return (rv[0] if rv else None) if one else rv

def current_user():
    user = session.get('user')
    if not user:
        return None
    return query_db("SELECT id, username, role, password_hash FROM users WHERE username = ?", (user,), one=True)

def login_required(role=None):
    def decorator(f):
        from functools import wraps
        @wraps(f)
        def wrapped(*args, **kwargs):
            if not session.get('user'):
                flash("Please log in first.", "warning")
                return redirect(url_for('login', next=request.path))
            if role:
                u = current_user()
                if not u or u['role'] != role:
                    flash("You don't have permission to view that page.", "danger")
                    return redirect(url_for('index'))
            return f(*args, **kwargs)
        return wrapped
    return decorator

@app.route('/')
def index():
    return render_template('index.html', user=current_user())

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username'].strip()
        password = request.form['password']
        user = query_db("SELECT * FROM users WHERE username = ?", (username,), one=True)
        if user and check_password(user['password_hash'], password):
            session['user'] = username
            flash("Logged in successfully.", "success")
            nxt = request.args.get('next') or url_for('index')
            return redirect(nxt)
        flash("Invalid credentials.", "danger")
    return render_template('login.html', user=current_user())

@app.route('/logout')
def logout():
    session.pop('user', None)
    flash("Logged out.", "info")
    return redirect(url_for('index'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username'].strip()
        password = request.form['password']
        confirm = request.form.get('confirm')
        if not username or not password:
            flash("Fill all fields.", "warning")
            return redirect(url_for('register'))
        if password != confirm:
            flash("Passwords do not match.", "warning")
            return redirect(url_for('register'))
        existing = query_db("SELECT id FROM users WHERE username = ?", (username,), one=True)
        if existing:
            flash("Username already exists.", "warning")
            return redirect(url_for('register'))
        pw_hash = hash_password(password)
        query_db("INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)", (username, pw_hash, 'student'))
        flash("Account created. You can now log in.", "success")
        return redirect(url_for('login'))
    return render_template('register.html', user=current_user())

@app.route('/change-password', methods=['GET', 'POST'])
@login_required()
def change_password():
    if request.method == 'POST':
        old = request.form['old_password']
        new = request.form['new_password']
        confirm = request.form['confirm_password']
        user = current_user()
        if not check_password(user['password_hash'], old):
            flash("Old password incorrect.", "danger")
            return redirect(url_for('change_password'))
        if new != confirm:
            flash("New passwords do not match.", "warning")
            return redirect(url_for('change_password'))
        new_hash = hash_password(new)
        query_db("UPDATE users SET password_hash = ? WHERE username = ?", (new_hash, user['username']))
        flash("Password changed successfully.", "success")
        return redirect(url_for('index'))
    return render_template('change_password.html', user=current_user())

@app.route('/student', methods=['GET', 'POST'])
@login_required(role='student')
def student():
    user = current_user()
    if request.method == 'POST':
        action = request.form.get('action')
        if action not in ('Present', 'Absent'):
            flash("Invalid action.", "danger")
            return redirect(url_for('student'))
        today = date.today().isoformat()
        existing = query_db("SELECT id FROM attendance WHERE user_id = ? AND date = ?", (user['id'], today), one=True)
        if existing:
            query_db("UPDATE attendance SET status = ?, timestamp = ? WHERE id = ?", (action, datetime.utcnow().isoformat(), existing['id']))
        else:
            query_db("INSERT INTO attendance (user_id, date, status, timestamp) VALUES (?, ?, ?, ?)",
                     (user['id'], today, action, datetime.utcnow().isoformat()))
        flash(f"Marked {action} for {today}.", "success")
        return redirect(url_for('student'))
    rows = query_db("""
        SELECT a.date, a.status, a.timestamp
        FROM attendance a
        JOIN users u ON u.id = a.user_id
        WHERE u.username = ?
        ORDER BY a.date DESC
    """, (user['username'],))
    return render_template('student.html', user=user, records=rows)

@app.route('/teacher')
@login_required(role='teacher')
def teacher():
    rows = query_db("""
        SELECT a.id, u.username, a.date, a.status, a.timestamp
        FROM attendance a
        JOIN users u ON u.id = a.user_id
        ORDER BY a.date DESC, u.username
    """)
    stats = {}
    for r in rows:
        name = r['username']
        stats.setdefault(name, {'Present':0, 'Absent':0})
        stats[name][r['status']] += 1
    return render_template('teacher.html', user=current_user(), rows=rows, stats=stats)

@app.route('/export-csv')
@login_required(role='teacher')
def export_csv():
    rows = query_db("""
        SELECT u.username, a.date, a.status, a.timestamp
        FROM attendance a
        JOIN users u ON u.id = a.user_id
        ORDER BY a.date DESC, u.username
    """)
    si = io.StringIO()
    cw = csv.writer(si)
    cw.writerow(['username','date','status','timestamp'])
    for r in rows:
        cw.writerow([r['username'], r['date'], r['status'], r['timestamp']])
    mem = io.BytesIO()
    mem.write(si.getvalue().encode('utf-8'))
    mem.seek(0)
    filename = f"attendance_{date.today().isoformat()}.csv"
    return send_file(mem, mimetype='text/csv', as_attachment=True, download_name=filename)

@app.route('/admin', methods=['GET', 'POST'])
@login_required(role='teacher')
def admin():
    if request.method == 'POST':
        action = request.form.get('action')
        if action == 'add':
            username = request.form['username'].strip()
            pwd = request.form['password']
            role = request.form['role']
            if query_db("SELECT id FROM users WHERE username = ?", (username,), one=True):
                flash("Username already exists.", "warning")
            else:
                pw_hash = hash_password(pwd)
                query_db("INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)", (username, pw_hash, role))
                flash("User created.", "success")
        elif action == 'delete':
            uid = int(request.form['user_id'])
            query_db("DELETE FROM users WHERE id = ?", (uid,))
            query_db("DELETE FROM attendance WHERE user_id = ?", (uid,))
            flash("User removed.", "info")
        return redirect(url_for('admin'))
    users = query_db("SELECT id, username, role FROM users ORDER BY role, username")
    return render_template('admin.html', user=current_user(), users=users)

if __name__ == '__main__':
    app.run(debug=True)
